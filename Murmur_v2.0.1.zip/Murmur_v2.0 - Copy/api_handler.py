from openai import OpenAI
from config import OPENAI_API_KEY,CONFIG,LAST_CALL
import re
import requests
import datetime
client = OpenAI(api_key=OPENAI_API_KEY)
timex=0
timey=0
BACKEND_URL = "https://murmur-v1-0.onrender.com/get_word_pairs"
BACKEND_URL_QUOTES = "https://murmur-v1-0.onrender.com/get_quotes"

def get_word_pairs(selected_words):
    # Input your data here
    payload = {
        "selected_words": selected_words,
        "customization": CONFIG['customization']
    }

    try:
        response = requests.post(BACKEND_URL, json=payload)

        if response.status_code == 200:
            data = response.json()
            print("=== Word Pairs ===")
            #print(data["result"])
            raw_output=data["result"]
        else:
            print(f"Error {response.status_code}: {response.text}")
            raw_output=[]
    except Exception as e:
        print(f"Request failed: {e}")

    #print(raw_output)
    #print("RAW OUTPUT FROM OPENAI:\n", raw_output)
    word_pairs = clean_lines0(raw_output)
    print(word_pairs)
    global timex
    global timey
    timex = datetime.datetime.now()
    timey=len(word_pairs)


    

    return word_pairs, timex

def get_sentences(word_list):
    """Get example sentences from OpenAI."""
    sentence_prompt = (
        f"For each of the following words in language where each entry in the list is [language,[words]], give a sample sentence in language and its English translation. "
        f"Format:[emoji for language] [insert sentence in language] \n [emoji for english] [insert translation in english]"
        + str(word_list)
    )

    sentence_completion = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": sentence_prompt}]
    )

    return sentence_completion.choices[0].message.content

def get_quotes(english_words, language):
    payload = {
        "eng_words": english_words,
    }

    try:
        response = requests.post(BACKEND_URL_QUOTES, json=payload)

        if response.status_code == 200:
            data = response.json()
            print("=== Word Pairs ===")
            #print(data["result"])
            raw_output=data["result"]
        else:
            print(f"Error {response.status_code}: {response.text}")
            raw_output=[]
    except Exception as e:
        print(f"Request failed: {e}")
    return str(raw_output)



def clean_lines0(input_string):
    # Remove all extra whitespace (including tabs and newlines)
    cleaned = re.sub(r'\s+', ' ', input_string.strip())
    
    # Split into individual entries
    entries = re.findall(r'\[([^\[\]]+)\]', cleaned)
    
    # Clean each entry and restructure
    result = []
    for entry in entries:
        # Split components, handling commas inside quotes
        components = re.split(r',\s*(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)', entry)
        cleaned_components = []
        for comp in components:
            comp = comp.strip()
            # Remove surrounding quotes if present
            if (comp.startswith('"') and comp.endswith('"')) or \
               (comp.startswith("'") and comp.endswith("'")):
                comp = comp[1:-1]
            # Remove any remaining extra spaces
            comp = re.sub(r'\s+', ' ', comp.strip())
            cleaned_components.append(comp)
        
        # Restructure: [0, 1, 2+3, 4+5]
        if len(cleaned_components) == 6:
            merged_entry = [
                cleaned_components[0],  # Word (e.g., "recolas")
                cleaned_components[1],  # Translation (e.g., "snacks")
                f"{cleaned_components[2]} {cleaned_components[3]}",  # 🇪🇸 + Sentence
                f"{cleaned_components[4]} {cleaned_components[5]}"   # 🇺🇸 + Sentence
            ]
            result.append(merged_entry)
    
    return result

def t2():
    return timex