import time
import datetime
import tkinter as tk
from config import is_valid_time, RESET_TIMEOUT, LANGUAGE, CONFIG
from api_handler import timex, timey

class Scheduler:
    def __init__(self, root, word_manager, ui):
        self.root = root
        self.word_manager = word_manager
        self.ui = ui
        self.last_drop_time = time.time()

    def check_reset(self):
        if time.time() - self.last_drop_time > RESET_TIMEOUT:
            self.ui.output.config(state='normal')
            self.ui.output.delete('1.0', tk.END)
            #self.ui.output.insert(tk.END, "Path will appear here and be copied to clipboard.")
            self.ui.output.config(state='disabled')
        self.root.after(1000, self.check_reset)

    def schedule_fetches(self):
        from api_handler import timex
        timex2=timex
        print(timex2)
        if is_valid_time(timex2):
            print('validtime')
            self.word_manager.fetch_german_words()
            #print(self.engw)
            self.word_manager.fetch_quotes()
            # Use config frequency
        #print((int(CONFIG["api_frequency"]) * 60 * 60 * 1000))
        self.root.after((int(CONFIG["api_frequency"]) * 60 * 60 * 1000), self.schedule_fetches)

    
    def rotate_german_word(self):
        word = self.word_manager.get_next_word()
        from api_handler import timey
        if word:
            print('timey', timey)
            if timey==0:
                timey=1
            self.ui.update_word_display(word)
            # Update next word time display
            next_time = (datetime.datetime.now() + datetime.timedelta(minutes=int((int(CONFIG["api_frequency"])*60)/timey))).strftime("%H:%M")
            self.ui.next_word_label.config(text=f"Next word at {next_time}")

        if timey==0:
                timey=1
        self.root.after((int(int(CONFIG["api_frequency"])*60 * 60 * 1000/timey)), self.rotate_german_word)

    def rotate_quote(self):
        from api_handler import timey
        if timey==0:
                timey=1
        quote, meta = self.word_manager.get_next_quote()
        self.ui.update_quote_display(quote, meta)
        self.root.after((int(int(CONFIG["api_frequency"])*60 * 60 * 1000/timey)), self.rotate_quote)

    def loading_words(self):
        if not self.word_manager.get_next_word: 
            self.ui.update_word_display('Loading')
            # Update next word time display
            next_time = (datetime.datetime.now() + datetime.timedelta(minutes=int((int(CONFIG["api_frequency"])*60)/120))).strftime("%H:%M")
            self.ui.next_word_label.config(text=f"Error, Loading again at {next_time} ...")
            self.root.after((int(int(CONFIG["api_frequency"])*60 * 60 * 1000/120)), self.loading_words())