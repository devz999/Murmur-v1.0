import requests
import json

# Your deployed backend URL
BACKEND_URL = "https://murmur-v1-0.onrender.com/get_word_pairs"

# Input your data here
selected_words = [["German", ["Hallo", "Tschüss", "Danke", "Bitte", "Entschuldigung", 
                              "Ja", "Nein", "Guten Morgen", "Gute Nacht", "Wie geht's?",
                              "Ich liebe dich", "Wasser", "Essen", "Trinken", "Kaffee",
                              "Bier", "Wein", "Freund", "Familie"]]]

customization = "daily conversations in a cafe"

payload = {
    "selected_words": selected_words,
    "customization": customization
}

try:
    response = requests.post(BACKEND_URL, json=payload)

    if response.status_code == 200:
        data = response.json()
        print("=== Word Pairs ===")
        print(data["result"])
    else:
        print(f"Error {response.status_code}: {response.text}")
except Exception as e:
    print(f"Request failed: {e}")
