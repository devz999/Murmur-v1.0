import tkinter as tk
from tkinter import ttk
from config import THEMES, LANGUAGES, CONFIG, save_config

class AppUI:
    def __init__(self, root, word_manager):
        self.root = root
        self.word_manager = word_manager
        self.setup_ui()
        self.setup_settings_button()
        self.setup_close_button()
        self.apply_theme()  # Apply theme immediately
        self.update_word_display()
        self.update_window_size()      
        self.main_widgets = []

    def setup_ui(self):
        self.root.overrideredirect(True)
        self.root.title("Murmur💬 v1.0")
        self.root.attributes('-topmost', True)
        self.root.configure(bg=CONFIG["colors"]["bg"])
        self.main_widgets = []
        self.root.geometry(CONFIG["window_size"])
        self.root.resizable(True, True)

        # Main label with extra space
        self.label = tk.Label(
            self.root, text="Murmur💬 v1.0", 
            bg=CONFIG["colors"]["bg"], fg=CONFIG["colors"]["text"],
            font=("Arial", 14, "bold")
        )
        self.label.pack(pady=(0, 5))  # Added more space here
        self.main_widgets.append(self.label)
        self.label2 = tk.Label(
            self.root, text="AI based passive language learning; d99", 
            bg=CONFIG["colors"]["bg"], fg=CONFIG["colors"]["text"],
            font=("Arial", 8, "italic")
        )
        self.label2.pack(pady=(0, 8))  # Added more space here
        self.main_widgets.append(self.label2)


        # Word frame
        self.word_frame = tk.Frame(self.root, bg=CONFIG["colors"]["bg"])
        self.word_frame.pack(pady=(0, 10))
        self.main_widgets.append(self.word_frame)

        self.german_label = tk.Label(
            self.word_frame, text="", 
            fg=CONFIG["colors"]["word_foreign"], bg=CONFIG["colors"]["bg"],
            font=("Arial", 14, "bold")
        )
        self.german_label.pack(side="left", expand=True)
        self.main_widgets.append(self.german_label)

        self.english_label = tk.Label(
            self.word_frame, text="", 
            fg=CONFIG["colors"]["word_english"], bg=CONFIG["colors"]["bg"],
            font=("Arial", 14, "bold")
        )
        self.english_label.pack(side="right", expand=True)
        self.main_widgets.append(self.english_label)

        # Sentences
        self.sentence_de = tk.Label(
            self.root, text="", 
            fg=CONFIG["colors"]["sentence_foreign"], bg=CONFIG["colors"]["bg"],
            font=("Segoe UI Emoji", 9), wraplength=300, justify="center"
        )
        self.sentence_de.pack(pady=(0, 5))
        self.main_widgets.append(self.sentence_de)

        self.sentence_en = tk.Label(
            self.root, text="", 
            fg=CONFIG["colors"]["sentence_english"], bg=CONFIG["colors"]["bg"],
            font=("Segoe UI Emoji", 9), wraplength=300, justify="center"
        )
        self.sentence_en.pack(pady=(0, 10))
        self.main_widgets.append(self.sentence_en)

        self.next_word_label = tk.Label(
            self.root, text="", bg=CONFIG["colors"]["bg"], fg="white",
            font=("Arial", 8), justify="center", wraplength=300
        )
        self.next_word_label.pack(pady=(0, 5))
        self.main_widgets.append(self.next_word_label)
        # Quote labels
        self.quote_label = tk.Label(
            self.root, text="", 
            fg=CONFIG["colors"]["quote"], bg=CONFIG["colors"]["bg"],
            font=("Arial", 10, "italic"), justify="center", wraplength=300
        )
        self.quote_label.pack(pady=(0, 2))
        self.main_widgets.append(self.quote_label)

        self.quote_meta = tk.Label(
            self.root, text="", 
            fg=CONFIG["colors"]["meta"], bg=CONFIG["colors"]["bg"],
            font=("Arial", 9), justify="center", wraplength=300
        )
        self.quote_meta.pack(pady=(0, 10))
        self.main_widgets.append(self.quote_meta)

        
        # Calculate and set optimal window height
        self.update_window_size()

        # Bindings
        self.root.bind("<Configure>", self.update_wraplength)
        self.root.bind("<ButtonPress-1>", self.start_drag)
        self.root.bind("<B1-Motion>", self.on_drag)
        

    def setup_close_button(self):
        self.close_btn = tk.Button(
            self.root, text="✕", command=self.root.destroy,
            bg="red", fg="white", bd=0, font=("Arial", 8, "bold"),
            activebackground="darkred", padx=3, pady=0
        )
        self.close_btn.place(relx=1, x=-5, y=5, anchor="ne")

    def setup_settings_button(self):
        self.settings_btn = tk.Button(
            self.root, text="⚙", command=self.show_settings,
            bg="#1e1e1e", fg="white", bd=0, font=("Arial", 8),
            activebackground="#333", padx=3, pady=0
        )
        self.settings_btn.place(relx=1, x=-25, y=5, anchor="ne")

    def update_wraplength(self, event=None):
        wrap = self.root.winfo_width() - 50
        for widget in [self.quote_label, self.quote_meta, self.sentence_de, self.sentence_en]:
            widget.config(wraplength=wrap)
    def update_window_size(self):
        self.root.update_idletasks()  # Ensure all widgets are rendered
        
        # Calculate required height
        total_height = (
            self.label.winfo_reqheight() +
            self.label2.winfo_reqheight() +
            self.word_frame.winfo_reqheight() +
            self.sentence_de.winfo_reqheight() +
            self.sentence_en.winfo_reqheight() +
            self.next_word_label.winfo_reqheight() +
            self.quote_label.winfo_reqheight() +
            self.quote_meta.winfo_reqheight() +
            35  # Padding
        )
        
        # Get current width or use default
        current_width = max(self.root.winfo_width()-100,250)
        
        # Update config and window size
        new_size = f"{current_width}x{total_height}"
        CONFIG["window_size"] = new_size
        self.root.geometry(new_size)

    def update_window_size_settings(self):
        self.root.update_idletasks()  # Ensure all widgets are rendered
        
        # Calculate required height
        total_height = (500)
            
        # Get current width or use default
        current_width = self.root.winfo_width() or 350
        
        # Update config and window size
        new_size = f"{current_width}x{total_height}"
        CONFIG["window_size"] = new_size
        self.root.geometry(new_size)

    def start_drag(self, event):
        self.root._drag_start_x = event.x
        self.root._drag_start_y = event.y

    def on_drag(self, event):
        x = self.root.winfo_x() + (event.x - self.root._drag_start_x)
        y = self.root.winfo_y() + (event.y - self.root._drag_start_y)
        self.root.geometry(f"+{x}+{y}")

    def update_word_display(self, word=None):
        """Update the display with a new word pair"""
        if word is None:
            word = self.word_manager.get_next_word()
        
        if word:
            print(word)
            print(type(word))
            [g, e, g_sent, e_sent] = word
            self.german_label.config(text=g)
            self.english_label.config(text=e)
            self.sentence_de.config(text=g_sent)
            self.sentence_en.config(text=e_sent)
        else:
            # Display placeholders if no word is available
            self.german_label.config(text="Error")
            self.english_label.config(text="...")
            self.sentence_de.config(text="")
            self.sentence_en.config(text="")

    def update_quote_display(self, quote, meta):
        if quote:
            self.quote_label.config(text=f'"{quote.strip()}')
            self.quote_meta.config(text=meta.strip())
            self.root.update_idletasks()
            self.show_settings()
            self.show_main()     
               

    def show_settings(self):
        # Hide main widget
        print("clicked")
        self.update_window_size_settings()
        self.label.pack_forget()
        self.label2.pack_forget()
        self.word_frame.pack_forget()
        self.german_label.pack_forget()
        self.english_label.pack_forget()
        self.sentence_de.pack_forget()
        self.sentence_en.pack_forget()
        self.next_word_label.pack_forget()
        self.quote_label.pack_forget()
        self.quote_meta.pack_forget()

        # Settings frame
        # Create simple settings panel
        self.settings_frame = tk.Frame(self.root, bg=CONFIG["colors"]["bg"])
        self.settings_frame.pack(fill="both", expand=True)
        

        # Back button
         # Add back button
        tk.Button(
            self.settings_frame,
            text="← Back to Main",
            command=self.show_main,
            bg=CONFIG["colors"]["bg"],
            fg=CONFIG["colors"]["text"]
        ).pack(pady=20)

        # Theme selection
        theme_frame = tk.LabelFrame(self.settings_frame, text="Theme", bg="#1e1e1e", fg="white")
        theme_frame.pack(fill="x", padx=5, pady=5)
        
        self.theme_var = tk.StringVar(value=CONFIG["theme"])
        tk.Radiobutton(
            theme_frame, text="Dark", variable=self.theme_var, value="dark",
            bg="#1e1e1e", fg="white", selectcolor="#333"
        ).pack(anchor="w")
        tk.Radiobutton(
            theme_frame, text="Light", variable=self.theme_var, value="light",
            bg="#1e1e1e", fg="white", selectcolor="#333"
        ).pack(anchor="w")

        # Language selection
        lang_frame = tk.LabelFrame(self.settings_frame, text="Languages (max 10)", bg="#1e1e1e", fg="white")
        lang_frame.pack(fill="x", padx=5, pady=5)
        
        self.lang_listbox = tk.Listbox(lang_frame, selectmode=tk.MULTIPLE, height=6, bg="#333", fg="white")
        for lang in LANGUAGES:
            self.lang_listbox.insert(tk.END, lang)
            if lang in CONFIG["languages"]:
                self.lang_listbox.select_set(LANGUAGES.index(lang))
        self.lang_listbox.pack(fill="x")

        # API Frequency
        freq_frame = tk.LabelFrame(self.settings_frame, text="10 words every [...] hours", bg="#1e1e1e", fg="white")
        freq_frame.pack(fill="x", padx=5, pady=5)
        
        self.freq_var = tk.IntVar(value=CONFIG["api_frequency"])
        ttk.Combobox(
            freq_frame, textvariable=self.freq_var,
            values=[2, 4, 8, 12], state="readonly"
        ).pack(fill="x")

        # Customization
        custom_frame = tk.LabelFrame(self.settings_frame, text="Customization (max 100 chars)", bg="#1e1e1e", fg="white")
        custom_frame.pack(fill="x", padx=5, pady=5)
        
        self.custom_var = tk.StringVar(value=CONFIG["customization"])
        tk.Entry(
            custom_frame, textvariable=self.custom_var,
            bg="#333", fg="white", insertbackground="white"
        ).pack(fill="x")
        tk.Label(
            custom_frame, text="Will be added to API prompts",
            bg="#1e1e1e", fg="gray", font=("Arial", 7)
        ).pack()

        # Premium button
        tk.Button(
            self.settings_frame, text="Premium at 1$/month!", command=self.open_premium,
            bg="gold", fg="black", font=("Arial", 9, "bold")
        ).pack(pady=10)

        # Save button
        tk.Button(
            self.settings_frame, text="Save Settings", command=self.save_settings,
            bg="green", fg="white", font=("Arial", 9, "bold")
        ).pack(pady=5)

    def show_main(self):
        
        if hasattr(self, 'settings_frame'):
            self.settings_frame.destroy()
        
        # Show all main widgets
        self.label.pack()
        self.label2.pack()
        self.word_frame.pack()
        self.german_label.pack()
        self.english_label.pack()
        self.sentence_de.pack()
        self.sentence_en.pack()
        self.next_word_label.pack()
        self.quote_label.pack()
        self.quote_meta.pack()
        # Force word display update
        self.update_window_size()        
        self.root.update_idletasks()


    def save_settings(self):
        # Get selected languages
        selected_langs = [LANGUAGES[i] for i in self.lang_listbox.curselection()][:10]
        
        CONFIG.update({
            "theme": self.theme_var.get(),
            "colors": THEMES[self.theme_var.get()],
            "languages": selected_langs,
            "api_frequency": self.freq_var.get(),
            "customization": self.custom_var.get()[:100]
        })
        
        save_config(CONFIG)
        self.apply_theme()
        self.show_main()

    def apply_theme(self):
        colors = CONFIG["colors"]
        self.root.configure(bg=colors["bg"])
        
        # List of widgets with their configurable properties
        widget_configs = [
            (self.label, {"bg": colors["bg"], "fg": colors["text"]}),
            (self.label2, {"bg": colors["bg"], "fg": colors["text"]}),
            (self.word_frame, {"bg": colors["bg"]}),
            (self.german_label, {"bg": colors["bg"], "fg": colors["word_foreign"]}),
            (self.english_label, {"bg": colors["bg"], "fg": colors["word_english"]}),
            (self.sentence_de, {"bg": colors["bg"], "fg": colors["sentence_foreign"]}),
            (self.sentence_en, {"bg": colors["bg"], "fg": colors["sentence_english"]}),
            (self.quote_label, {"bg": colors["bg"], "fg": colors["quote"]}),
            (self.quote_meta, {"bg": colors["bg"], "fg": colors["meta"]}),
            (self.next_word_label, {"bg": colors["bg"], "fg": colors["next_word_label"]}),
        ]
        
        for widget, config in widget_configs:
            try:
                widget.config(**config)
            except tk.TclError as e:
                print(f"Warning: Could not configure {widget}: {e}")
                # Try configuring just the background if foreground failed
                if "fg" in config:
                    try:
                        widget.config(bg=config["bg"])
                    except tk.TclError:
                        pass

    def open_premium(self):
        import webbrowser
        webbrowser.open("https://www.google.com/search?q=Murmur+Premium")


    

    