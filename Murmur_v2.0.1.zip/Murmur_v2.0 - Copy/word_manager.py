import random
import csv
import os
from data_processing import clean_lines, clean_lines2
from api_handler import get_word_pairs, get_sentences, get_quotes, timex
from config import CSV_PATH, LANGUAGE, LANGUAGE_EMOJI, ENG_EMOJI, is_valid_time, CONFIG
import sys

folder='assets\\languages\\'
class WordManager:
    def __init__(self):
        self.german_words = []
        self.quotes = []
        self.word_index = -1
        self.quote_index = 0
        self.engw = []
        #self.fetch_german_words()  # Fetch words immediately

    def get_next_word(self):
        """Get the next word pair to display"""
        if not self.german_words:
            self.fetch_german_words()  # Ensure we have words
        
        if self.german_words:
            word = self.german_words[self.word_index]
            print(word)
            self.word_index += 1
            return word
        return None

    def fetch_german_words(self):
        if not is_valid_time(timex):
            print("Not fetching words - outside valid time window")
            return

        try:
            print(f"Attempting to fetch words for languages: {CONFIG["languages"]}")
            
            words_per_lang = 20 // len(CONFIG["languages"])
            remainder = 20 % len(CONFIG["languages"])
            all_selected_words = []
            all_selected_words0 = []
            
            for lang in CONFIG["languages"]:
                str0=str(f"{folder}{lang.lower()}.txt")
                csv_path = self.resource_path(str0)
                print(f"Checking file at: {csv_path}")
                
                if not os.path.exists(csv_path):
                    print(f"File not found: {csv_path}")
                    continue
                    
                with open(csv_path, newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    lang_words = [row[0].strip() for row in reader if row]
                    print(f"Found {len(lang_words)} words for {lang}")
                    
                    if lang_words:
                        sample = random.sample(lang_words, min(words_per_lang, len(lang_words)))
                        all_selected_words.append([lang,sample])
                        print(f"Added {len(sample)} words from {lang}")

            '''# Add remainder words if needed
            if remainder > 0 and CONFIG["languages"]:
                lang = random.choice(CONFIG["languages"])
                csv_path = f"{folder}{lang.lower()}.txt"
                if os.path.exists(csv_path):
                    with open(csv_path, newline='', encoding='utf-8') as f:
                        reader = csv.reader(f)
                        lang_words = [row[0].strip() for row in reader if row]
                        if lang_words:
                            sample = random.sample(lang_words, min(remainder, len(lang_words)))
                            all_selected_words.append([lang,sample])
                            print(f"Added {len(sample)} remainder words from {lang}")
'''
            if not all_selected_words:
                print("No words found in any files!")
                return

            print(f"Selected {len(all_selected_words)} words total")
            
            # Rest of your word processing logic...
            word_list_for_sentence = "\n".join(f"{word} - (translation)" for word in all_selected_words)
            
            # For testing, create dummy data
            '''self.german_words = [
                ("Hola", "Hello", "Hola, ¿cómo estás?", "Hello, how are you?"),
                ("Adiós", "Goodbye", "Adiós, amigo", "Goodbye, friend")
            ]'''
            #print(all_selected_words)
            self.german_words=get_word_pairs(all_selected_words)[0]
            print(self.german_words)
            print(f"Created {len(self.german_words)} word pairs for display")
            self.engw = [sub[1] for sub in self.german_words]
            print(self.engw)

        except Exception as e:
            print(f"Error in fetch_german_words: {str(e)}")
            import traceback
            traceback.print_exc()

    def fetch_quotes(self):
        if not is_valid_time(timex):
            return

        try:
            raw_quotes = get_quotes(self.engw, LANGUAGE)
            self.quotes = clean_lines(raw_quotes)
            print(self.quotes)
        except Exception as e:
            print("Failed to fetch quotes:", e)

    def get_next_quote(self):
        if not self.quotes:
            raw_quotes = get_quotes(self.engw, LANGUAGE)
            self.quotes = clean_lines(raw_quotes)
        
        raw = self.quotes[self.quote_index % len(self.quotes)]
        self.quote_index += 1
        if "—" in raw:
            quote_part, meta_part = raw.split("—", 1)
            return quote_part.strip(), meta_part.strip()
        return raw.strip(), ""

    def resource_path(self,relative_path):
        """Get absolute path to resource, works for dev and for PyInstaller .exe"""
        try:
            base_path = sys._MEIPASS  # this exists when in .exe mode
        except Exception:
            base_path = os.path.abspath(".")

        return os.path.join(base_path, relative_path)
    

