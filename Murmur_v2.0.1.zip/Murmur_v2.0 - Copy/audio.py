import tkinter as tk
from tkinter import messagebox
import openai
import threading
from playsound import playsound

# 🔐 Your OpenAI API key
OPENAI_API_KEY = "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"
openai.api_key = OPENAI_API_KEY

OUTPUT_FILE = "output.mp3"

class TextToSpeechApp:
    def __init__(self, root):
        self.root = root
        self.root.title("GPT TTS Speaker")

        # Input text box
        self.text_box = tk.Text(root, height=10, width=50)
        self.text_box.pack(pady=10)
        self.text_box.insert("1.0", "Type your message here...")

        # Buttons
        tk.Button(root, text="🗣️ Generate Speech", command=self.start_tts).pack(pady=5)
        tk.Button(root, text="▶️ Play Audio", command=self.play_audio).pack(pady=5)

    def start_tts(self):
        text = self.text_box.get("1.0", tk.END).strip()
        if not text:
            messagebox.showerror("Error", "Please enter some text.")
            return
        threading.Thread(target=self.generate_speech, args=(text,)).start()

    def generate_speech(self, text):
        try:
            response = openai.audio.speech.create(
                model="tts-1",
                voice="fable",  # Available: alloy, echo, fable, onyx, nova, shimmer
                input=text
            )
            with open(OUTPUT_FILE, "wb") as f:
                f.write(response.content)
            messagebox.showinfo("Success", "Speech audio generated.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def play_audio(self):
        if not os.path.exists(OUTPUT_FILE):
            messagebox.showerror("Error", "No audio file found. Generate speech first.")
            return
        threading.Thread(target=playsound, args=(OUTPUT_FILE,)).start()

if __name__ == "__main__":
    import os
    root = tk.Tk()
    root.geometry("500x300")
    app = TextToSpeechApp(root)
    root.mainloop()
