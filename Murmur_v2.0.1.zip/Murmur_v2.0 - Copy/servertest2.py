import requests
import json


try:
    response = requests.post("https://murmur-v1-0.onrender.com/",(''))

    if response.status_code == 200:
        data = response.json()
        print("=== Word Pairs ===")
        print(data["result"])
    else:
        print(f"Error {response.status_code}: {response.text}")
except Exception as e:
    print(f"Request failed: {e}")
