from tkinterdnd2 import TkinterDnD
from ui import AppUI
from word_manager import WordManager
from scheduler import Scheduler
from config import LANGUAGE  # Added import

def main():
    root = TkinterDnD.Tk()
    word_manager = WordManager()
    app_ui = AppUI(root, word_manager)

    scheduler = Scheduler(root, word_manager, app_ui)  # Added app_ui parameter

        
    # Start scheduled tasks
    scheduler.schedule_fetches()
    scheduler.rotate_german_word()
    scheduler.rotate_quote()
    scheduler.loading_words()
    root.mainloop()
    

if __name__ == "__main__":
    main()
