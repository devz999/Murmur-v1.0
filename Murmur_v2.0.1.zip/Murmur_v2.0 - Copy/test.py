import requests

def get_word_pairs_from_server(selected_words):
    url = "https://murmur99-947927901780.asia-south1.run.app"
    payload = {"selected_words": ['vaca','granja'],"selected_words": 'For business' }
    
    response = requests.post(url, json=payload)
    print(response)
    if response.status_code == 200:
        print(response.json())
        data = response.json()
        raw_output = data.get("result", "")
        print('success')
        print(raw_output)
        return raw_output
    else:
        print(f"Error: {response.status_code} - {response.text}")
        print('fail')
        return None

get_word_pairs_from_server(['vaca','granja'])